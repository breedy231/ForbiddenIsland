import java.util.ArrayList;
import tester.*;
import javalib.impworld.*;
import javalib.worldimages.*;
import java.awt.Color;
import java.util.Iterator;
import java.util.Random;

// a generic iterator to iterate over lists
class IListIterator<T> implements Iterator<T> {
    IList<T> items;
    IListIterator(IList<T> items) {
        this.items = items;
    }
    // determines if a function has a next item
    public boolean hasNext() {
        return this.items.hasNextList();
    }
    // gets the next item in a list of items
    public T next() {
        ConsList<T> itemsAsCons = this.items.asCons();
        T answer = itemsAsCons.first;
        this.items = itemsAsCons.rest;
        return answer;
    }
    //EFFECT: removes the given item from the list
    public void remove() {
        throw new UnsupportedOperationException("Don't do this!");
    }
}



// a generic interface for the empty list
interface IList<T> extends Iterable<T> {
    // determines if this is a ConsList
    boolean isCons();
    // converts this to a ConsList
    ConsList<T> asCons();
    // an iterator for ILists
    Iterator<T> iterator();
    // determines if this has a next list
    boolean hasNextList();
    // returns this list without the given item
    IList<T> remove(T t);
}

// a class for a generic empty list
class MtList<T> implements IList<T> {

    // determines if this list is a ConsList
    public boolean isCons() {
        return false;
    }
    // converts this to a ConsList
    // empty case: throw an exception
    public ConsList<T> asCons() {
        throw new RuntimeException("Can't get the cons of an empty list!");
    }
    // an iterator
    public Iterator<T> iterator() {
        return new IListIterator<T>(this);
    }
    // determines if this has a next
    public boolean hasNextList() {
        return false;
    } 
    // returns this list without the given item
    public IList<T> remove(T t) {
        return this;
    }

}

// a class for a generic list
class ConsList<T> implements IList<T> {
    T first;
    IList<T> rest;
    ConsList(T first, IList<T> rest) {
        this.first = first;
        this.rest = rest;
    }

    // determines if this is a ConsList
    public boolean isCons() {
        return true;
    }

    // converts this into a ConsList
    public ConsList<T> asCons() {
        return this;
    }

    // an iterator
    public Iterator<T> iterator() {
        return new IListIterator<T>(this);
    }

    // determines if this has a next
    public boolean hasNextList() {
        return true;
    }

    // returns this list without the given item
    public IList<T> remove(T t) {
        if (this.first.equals(t)) {
            return this.rest;
        }
        else {
            return new ConsList<T>(this.first, this.rest.remove(t));
        }
    }


}    


//Represents a single square of the game area
class Cell {
    // represents absolute height of this cell, in feet
    double height;
    // In logical coordinates, with the origin at the 
    //  top-left corner of the screen
    int x;
    int y;
    // the four adjacent cells to this one
    Cell left;
    Cell top;
    Cell right;
    Cell bottom;
    // reports whether this cell is flooded or not
    boolean isFlooded;
    // the main cell constructor
    Cell(double height, int x, int y, Cell left, Cell right, Cell top, 
            Cell bottom, boolean isFlooded) {
        this.height = height;
        this.x = x;
        this.y = y;
        if (this.x == 635) {
            this.right = this;
        }
        if (this.x == 5) {
            this.left = this;
        }
        if (this.y == 635) {
            this.bottom = this;
        }
        if (this.y == 5) {
            this.top = this;
        }
        this.isFlooded = isFlooded;
    }

    // a constructor with input for height, x and y coordinates, and a boolean
    // with links initiliazed to null
    Cell(double height, int x, int y, boolean isFlooded) {
        this(height, x, y, null, null, null, null, isFlooded);
    }

    // EFFECT: changes the top cell of this cell to the input
    public void setTop(Cell c) {
        this.top = c;
    }
    // EFFECT: changes the bottom cell of this cell to the input
    public void setBottom(Cell c) {
        this.bottom = c;
    }
    // EFFECT: changes the left cell of this cell to the input
    public void setLeft(Cell c) {
        this.left = c;
    }
    // EFFECT: changes the right cell of this cell to the input
    public void setRight(Cell c) {
        this.right = c;
    }

    // determines if this is an OceanCell
    public boolean isOcean() {
        return false;
    }

    // draws the cell
    public WorldImage drawCell(int water) {
        return new RectangleImage(
                ForbiddenIslandWorld.CELL_SIZE, 
                ForbiddenIslandWorld.CELL_SIZE, 
                OutlineMode.SOLID, this.getColor(water));
    }

    // to place a cell on the world
    public WorldScene renderCell(WorldScene base, int water) {
        base.placeImageXY(this.drawCell(water), this.x * 10 + 5, 
                this.y * 10 + 5);
        return base;
    }

    // determines if this cell has a linked cell that is 
    // either flooded or an OceanCell
    public boolean hasFlood() {
        return (this.top.isFlooded || this.bottom.isFlooded ||
                this.left.isFlooded || this.right.isFlooded);
    }

    // gets the color of the cell corresponding to the height
    public Color getColor(double water) {
        if (this.isOcean()) {
            return this.getOceanColor();
        }
        else if ((!this.isFlooded) && this.height - water > 0) {
            return this.getLandColor(Math.abs(height - water));
        }
        else if (this.hasFlood() && this.height - water < 0) {
            return this.getFloodColor(height - water);
        }
        else {
            return this.getCautionColor(Math.abs(height - water));
        }
    }

    // gets the color of a land cell, depending on the height
    public Color getLandColor(double height) {
        int r = (int) height / 2 * 10 + 95;
        int g = (int) height / 2 * 5 + 175;
        int b = (int) (height / 2 * 15.75 + 3);
        if (r > 255) {
            r = 255;
        }
        else if (r <  95) {
            r = 95;
        }
        if (g > 255) {
            g = 255;
        }
        else if (g < 175) {
            g = 175;
        }
        if (b > 255) {
            b = 255;
        }
        else if (b <  3) {
            b = 3;
        }
        return new Color(r, g, b);
    }

    // gets the "Caution Color" of the cell, i.e. the color
    // of the cell if the cell's water height is below
    // the current water level
    public Color getCautionColor(double height) {
        return new Color(((int) (height / 1.25 * 5) + 95),
                ((int) (height / 1.25 * -9) + 175), 3);
    }

    // gets the color of a flooded cell, depending on the height
    public Color getFloodColor(double height) { 
        return new Color(0, 
                (((int) (height / 10 * 25)) + 100),
                (((int) (height / 10 * 51)) + 204));
    }

    // gets the color of an ocean cell
    public Color getOceanColor() {
        return new Color(0, 100, 204);
    }

    // determines if this cell is the same as that cell
    public boolean sameCell(Cell that) {
        return this.x == that.x && this.y == that.y;
    }

    // determines if this is a cell
    public boolean isCell() {
        return true;
    }

    // determines if this Cell has the input Player on it
    public boolean hasPlayer(Player p) {
        return this.x == p.x && this.y == p.y && this.isFlooded;
    } 
}

// Represents a single Ocean cell of the game area
class OceanCell extends Cell {
    OceanCell(double height, int x, int y, Cell left, Cell right, Cell top, 
            Cell bottom, boolean isFlooded) {
        super(height, x, y, left, right, top, bottom, isFlooded);
        this.isFlooded = true;
    }

    // ocean constructor w/o links
    OceanCell(double height, int x, int y, boolean isFlooded) {
        this(height, x, y, null, null, null, null, true);
    }

    // determines if this is an Ocean Cell
    public boolean isOcean() {
        return true;
    }

    public boolean isCell() {
        return false;
    }
}

// to represent a player in the Game
class Player {
    // the player's position
    int x;
    int y;
    // the list of helicopter parts the player currently has
    IList<Target> parts;
    // the amount of steps the player has taken in the game
    int steps;
    // the cells that are next to the player
    Cell left;
    Cell right;
    Cell top;
    Cell bottom;
    Player(int x, int y, IList<Target> parts, int steps, 
            Cell left, Cell right, Cell top, Cell bottom) {
        this.x = x;
        this.y = y;
        this.parts = parts;
        this.steps = steps;
        this.left = left;
        this.right = right;
        this.top = top;
        this.bottom = bottom;
    }
    // assigns the player an image
    public WorldImage drawPlayer(boolean isFirst) {
        if (isFirst) {
            return new FromFileImage("eggplant.png");
        }
        else {
            return new FromFileImage("glasses.png");
        }
    }
    // draws the score of the game given the number of steps taken by this player
    public WorldImage drawScore() {
        return new TextImage(Integer.toString(this.steps), 15, FontStyle.BOLD, Color.pink);
    }
    // draws the player based on whether the player is first or not
    public WorldScene renderPlayer(WorldScene base, boolean isFirst) {
        base.placeImageXY(this.drawPlayer(isFirst), this.x * 10 + 5, 
                this.y * 10 + 5);
        return base;
    }
    // moves the player onto the cell to the player's right
    public void moveRight() {
        this.x = this.x + 1;
        this.steps = this.steps + 1;
    }
    // moves the player onto the cell on the player's left
    public void moveLeft() {
        this.x = this.x - 1;
        this.steps = this.steps + 1;
    }
    // moves the player onto the cell below the player
    public void moveDown() {
        this.y = this.y + 1;
        this.steps = this.steps + 1;
    }
    // moves the player onto the cell above the player
    public void moveUp() {
        this.y = this.y - 1;
        this.steps = this.steps + 1;
    }
    // sets the cells so they are connected to the cells around them
    public void setCells(ArrayList<ArrayList<Cell>> arr) {
        if (this.y == 0) {
            this.top = arr.get(this.x).get(this.y);
        }
        else {
            this.top = arr.get(this.x).get(this.y - 1);
        }
        if (this.y == ForbiddenIslandWorld.ISLAND_SIZE) {
            this.bottom = arr.get(this.x).get(this.y);
        }
        else {
            this.bottom = arr.get(this.x).get(this.y + 1);
        }
        if (this.x == 0) {
            this.left = arr.get(this.x).get(this.y);
        }
        else {
            this.left = arr.get(this.x - 1).get(this.y);
        }
        if (this.x == ForbiddenIslandWorld.ISLAND_SIZE) {
            this.right = arr.get(this.x).get(this.y);
        }
        else {
            this.right = arr.get(this.x + 1).get(this.y);
        }

    }
    // places a person on the board
    public void placePerson(ArrayList<ArrayList<Cell>> arr) {
        int low = 1;
        int high = ForbiddenIslandWorld.ISLAND_SIZE;
        Double d = ((Math.floor(Math.random() * (1 + high - low)) + low));
        Double e = ((Math.floor(Math.random() * (1 + high - low)) + low));
        int i = d.intValue();
        int j = e.intValue();
        if (arr.get(i).get(j).isOcean()) {
            this.placePerson(arr);
        }
        else {
            this.x = i;
            this.y = j;
        }
    }
    // adds one part of the helicopter to the board
    public void addPart(Target part) {
        this.parts = new ConsList<Target>(part, this.parts);
    }
    // adds one to this player's steps every time they move a unit
    public void incSteps() {
        this.steps = this.steps + 1;
    }
    // determines where a player should move given a key stroke
    public void moveOnKey(String ke) {
        if ((ke.equals("a") && this.left.isCell()) || 
                (ke.equals("left") && this.left.isCell())) {
            this.moveLeft();    
        }
        if ((ke.equals("d") && this.right.isCell()) || 
                (ke.equals("right") && this.right.isCell())) {
            this.moveRight();    
        }
        if ((ke.equals("w") && this.top.isCell()) || 
                (ke.equals("up") && this.top.isCell())) {
            this.moveUp();    
        }
        if ((ke.equals("s") && this.bottom.isCell()) || 
                (ke.equals("down") && this.bottom.isCell())) {
            this.moveDown();    
        }

    }
    // determines if this player is on water (ocean or flooded land), 
    //  given the current board
    public boolean onWater(ArrayList<ArrayList<Cell>> arr) {
        return arr.get(this.x).get(this.y).isFlooded;
    }

    public IList<Cell> onFlood(IList<Cell> cells) {
        IList<Cell> cur = cells;
        IList<Cell> result = new MtList<Cell>();
        for (Cell c: cur) {
            if (c.x == this.x && c.y == this.y && c.isFlooded) {
                result = new ConsList<Cell>(c, result);
            }
        }
        return result;
    }
}
// to represent helicopter pieces that the player must pick up
class Target {
    // the part's position
    int x;
    int y;
    // boolean to determine if the target was picked up
    boolean isPicked;
    Target(int x, int y, boolean isPicked) {
        this.x = x;
        this.y = y;
        this.isPicked = isPicked;
    }
    // draws the helicopter targets
    public WorldImage drawTarget() {
        return new FromFileImage("gear.png");
    }


    // places the target onto the board given the target's x and y values
    public WorldScene renderTarget(WorldScene base) {
        base.placeImageXY(this.drawTarget(), this.x * 10 + 5, 
                this.y * 10 + 5);
        return base;
    }

    // randomly assigns this target's x and y values
    public void placeTarget(ArrayList<ArrayList<Cell>> arr) {
        int low = 1;
        int high = ForbiddenIslandWorld.ISLAND_SIZE;
        Double d = ((Math.floor(Math.random() * (1 + high - low)) + low));
        Double e = ((Math.floor(Math.random() * (1 + high - low)) + low));
        int i = d.intValue();
        int j = e.intValue();
        if (arr.get(i).get(j).isOcean()) {
            this.placeTarget(arr);
        }
        else {
            this.x = i;
            this.y = j;
        }
    }
    // determines if this item is a target
    public boolean isTarget() {
        return true;
    }

    // determines if this target's x and y values are also the x and y
    //  values of the given player
    public boolean hasPlayer(Player p) {
        return this.x == p.x && this.y == p.y;
    }

}



class HelicopterTarget extends Target {
    int x;
    int y;
    boolean isPicked;
    HelicopterTarget(int x, int y, boolean isPicked) {
        super(x, y, isPicked);
    }
    // generates the image of a helicopter
    public WorldImage drawHeli() {
        return new FromFileImage("helicopter.png");
    }
    // places this helicopter target onto the board
    public WorldScene renderHeli(WorldScene base) {
        base.placeImageXY(this.drawHeli(), this.x * 10 + 5, 
                this.y * 10 + 5);
        return base;
    }
    // if the given player has the same x and y values as this heli target,
    //  it is considered "picked". If not, it is considered not picked
    public void changePicked(Player p) {
        if ((this.x == p.x) && (this.y == p.y)) {
            this.isPicked = true;
        }
        else {
            this.isPicked = false;
        }
    }
    // places the helicopter in the middle of the board
    void placeHeli(ArrayList<ArrayList<Cell>> aaCell) {
        for (int i = 0; i < aaCell.size(); i = i + 1) {
            for (int j = 0; j < aaCell.get(i).size(); j = j + 1) {
                if (aaCell.get(i).get(j).height == ForbiddenIslandWorld.MAX_HEIGHT) {
                    this.x = aaCell.get(i).get(j).x;
                    this.y = aaCell.get(i).get(j).y;
                }
            }
        }       
    }
    // determines if both players have the same x and y values as the helicopter
    public boolean fly(Player p1, Player p2) {
        return ((this.x == p1.x && this.y == p1.y) && (this.x == p2.x && this.y == p2.y));
    }

}


class ForbiddenIslandWorld extends World {
    // All the cells of the game, including the ocean
    IList<Cell> board;
    // the current height of the ocean
    int waterHeight;
    // the players in the world
    Player p1;
    Player p2;
    // explicit tick counter for the world
    int tick;
    // the list of targets in the world
    ArrayList<Target> targets;
    // the helicopter, which can only appear after all the targets are picked up
    HelicopterTarget heli;
    // The size of the island
    static final int ISLAND_SIZE = 64;
    // The height and length of the window the game is running in
    static final int WINDOW_HEIGHT = (ForbiddenIslandWorld.ISLAND_SIZE + 1) * 10; 
    static final int WINDOW_LENGTH = (ForbiddenIslandWorld.ISLAND_SIZE + 1) * 10;
    // the size of cells in the game
    static final int CELL_SIZE = WINDOW_HEIGHT / 
            ForbiddenIslandWorld.ISLAND_SIZE;
    // imports the rules
    WorldImage img = new FromFileImage("Part1.png");
    // a cell in a mountain island that is the "peak", 
    // i.e. it is the highest cell and it is the center cell
    static final Cell MOUNTAIN_PEAK = new Cell(32.0, 32, 
            32, false);
    // the Maximum height of any cell
    static final Double MAX_HEIGHT = ForbiddenIslandWorld.MOUNTAIN_PEAK.height;

    // a constructor that takes in a width, height, board, and waterheight
    ForbiddenIslandWorld(int width, int height, IList<Cell> board,
            int waterHeight, Player p1, Player p2, int tick, 
            ArrayList<Target> targets, HelicopterTarget heli) {
        super();
        this.board = board;
        this.waterHeight = waterHeight;
        this.p1 = p1;
        this.p2 = p2;
        this.tick = tick;
        this.targets = targets;
        this.heli = heli;
    }
    // a constructor that takes in a board and waterheight and players
    ForbiddenIslandWorld(IList<Cell> board, int waterHeight, Player p1, 
            Player p2, ArrayList<Target> targets, HelicopterTarget heli) {
        this(WINDOW_LENGTH, WINDOW_HEIGHT, board, waterHeight, p1, p2, 0, targets, heli);

        this.targets = new ArrayList<Target>();
        this.targets.add(new Target(32, 32, false));
        this.targets.add(new Target(32, 33, false));
        this.targets.add(new Target(32, 34, false));
        this.targets.add(new Target(32, 35, false));
        this.targets.add(new Target(32, 36, false));
        this.heli = new HelicopterTarget(32, 32, true);

    }
    // a constructor that takes in only a water height
    ForbiddenIslandWorld(int waterHeight) {
        this.waterHeight = waterHeight;
    }
    // a constructor that takes in a string and updates the board
    ForbiddenIslandWorld(String s) {
        if (s.compareTo("r") == 0) {
            IList<Cell> cells = this.board;
            ArrayList<ArrayList<Cell>> arrR = this.genCells(this.genRandomHeights());
            Player player1 = this.p1;
            Player player2 = this.p2;
            ArrayList<Target> pieces = new ArrayList<Target>();
            ForbiddenIslandWorld start = this;
            HelicopterTarget helipiece = new HelicopterTarget(32, 32, false);
            cells = this.genBoard(arrR);
            this.board = cells;
            this.waterHeight = 0;
            player1 = new Player(0, 0, new MtList<Target>(), 0, null, null, null, null);
            player2 = new Player(0, 0, new MtList<Target>(), 0, null, null, null, null);
            player1.placePerson(arrR);
            player2.placePerson(arrR);
            player1.setCells(arrR);
            player2.setCells(arrR);
            this.p1 = player1; 
            this.p2 = player2;
            pieces.add(new Target(32, 32, false));
            pieces.add(new Target(32, 33, false));
            pieces.add(new Target(32, 34, false));
            pieces.add(new Target(32, 35, false));
            pieces.add(new Target(32, 36, false));
            for (Target t: pieces) {
                t.placeTarget(arrR);
            }
            if (pieces.isEmpty()) {
                helipiece = new HelicopterTarget(ForbiddenIslandWorld.MOUNTAIN_PEAK.x, 
                        ForbiddenIslandWorld.MOUNTAIN_PEAK.y, false);
                helipiece.placeHeli(arrR);
            }

            this.heli = helipiece;
            this.targets = pieces;
            start = new ForbiddenIslandWorld(cells, 0, player1, player2, pieces, helipiece);
        }
        if (s.compareTo("m") == 0) {
            IList<Cell> cells = this.board;
            ArrayList<ArrayList<Cell>> arrM = this.genCells(this.genMountainHeights());
            Player player1 = this.p1;
            Player player2 = this.p2;
            ArrayList<Target> pieces = new ArrayList<Target>();
            ForbiddenIslandWorld start = this;
            HelicopterTarget helipiece = new HelicopterTarget(32, 32, false);
            cells = this.genBoard(arrM);
            this.board = cells;
            this.waterHeight = 0;
            player1 = new Player(0, 0, new MtList<Target>(), 0, null, null, null, null);
            player2 = new Player(0, 0, new MtList<Target>(), 0, null, null, null, null);
            player1.placePerson(arrM);
            player2.placePerson(arrM);
            player1.setCells(arrM);
            player2.setCells(arrM);
            this.p1 = player1; 
            this.p2 = player2;
            pieces.add(new Target(32, 32, false));
            pieces.add(new Target(32, 33, false));
            pieces.add(new Target(32, 34, false));
            pieces.add(new Target(32, 35, false));
            pieces.add(new Target(32, 36, false));
            for (Target t: pieces) {
                t.placeTarget(arrM);
            }
            if (pieces.isEmpty()) {
                helipiece = new HelicopterTarget(ForbiddenIslandWorld.MOUNTAIN_PEAK.x, 
                        ForbiddenIslandWorld.MOUNTAIN_PEAK.y, false);
                helipiece.placeHeli(arrM);
            }

            this.heli = helipiece;
            this.targets = pieces;
            start = new ForbiddenIslandWorld(cells, 0, player1, player2, pieces, helipiece);
        }
    }
    // a constructor that initializes the waterheight at 0.
    ForbiddenIslandWorld() {
        this(0);
    }
    // to generate the random terrain heights
    public ArrayList<ArrayList<Double>> genRandomTerrain() {
        ArrayList<ArrayList<Double>> heights = new ArrayList<ArrayList<Double>>();
        for (int i = 0; i < ISLAND_SIZE + 1; i += 1) {
            ArrayList<Double> ys = new ArrayList<Double>();
            for (int j = 0; j < ISLAND_SIZE + 1; j += 1) {
                ys.add(0.0);
            }
            heights.add(ys);
        }
        heights.get(0).set(0, 0.0);
        heights.get(0).set(ISLAND_SIZE, 0.0);
        heights.get(ISLAND_SIZE).set(0, 0.0);
        heights.get(ISLAND_SIZE).set(ISLAND_SIZE, 0.0);
        heights.get(0).set(ISLAND_SIZE / 2, 1.0);
        heights.get(ISLAND_SIZE).set(ISLAND_SIZE / 2, 1.0);
        heights.get(ISLAND_SIZE / 2).set(0, 1.0);
        heights.get(ISLAND_SIZE / 2).set(ISLAND_SIZE, 1.0);
        heights.get(ISLAND_SIZE / 2).set(ISLAND_SIZE / 2, MAX_HEIGHT);

        this.terrainHelper(0, ForbiddenIslandWorld.ISLAND_SIZE, 0, 
                ForbiddenIslandWorld.ISLAND_SIZE, true, heights);

        return heights;
    }
    // to recursively assign random terrain height values by square sections
    //  of the board
    public void terrainHelper(int col1, int col2, 
            int row1, int row2, boolean first, ArrayList<ArrayList<Double>> heights) {
        Double tl;
        Double tr;
        Double bl;
        Double br;
        Double center;

        Random rand = new Random();

        tl = heights.get(col1).get(row1);
        tr = heights.get(col2).get(row1);
        bl = heights.get(col1).get(row2);
        br = heights.get(col2).get(row2);

        int i = row2 - row1;

        if (!first && i > 1) {
            if (heights.get((col1 + col2) / 2).get((row1 + row2) / 2) == 0) {
                center = heights.get((col1 + col2) / 2).set((row1 + row2) / 2,
                        (rand.nextInt(i) - rand.nextInt(i)) + ((tl + tr + bl + br) / 4));
            }
        }
        if (i > 1) {
            if (heights.get(col1).get((row1 + row2) / 2) == 0) {
                heights.get(col1).set(((row1 + row2) / 2), 
                        (rand.nextInt(1) + ((tl + bl) / 2)));
            }
            if (heights.get(col2).get((row1 + row2) / 2) == 0) {
                heights.get(col2).set(((row1 + row2) / 2), 
                        (rand.nextInt(1) + ((tr + br) / 2)));
            }
            if (heights.get((col1 + col2) / 2).get(row1) == 0) {
                heights.get((col1 + col2) / 2).set(row1, 
                        (rand.nextInt(1) + ((tl + tr) / 2)));
            }
            if (heights.get((col1 + col2) / 2).get(row2) == 0) {
                heights.get((col1 + col2) / 2).set(row2, 
                        (rand.nextInt(1) + ((bl + br) / 2)));
            }
            this.terrainHelper(col1, ((col1 + col2) / 2), row1, 
                    ((row1 + row2) / 2), false, heights);
            this.terrainHelper(((col1 + col2) / 2), col2, row1, 
                    ((row1 + row2) / 2), false, heights);
            this.terrainHelper(col1, ((col1 + col2) / 2), 
                    ((row1 + row2) / 2), row2, false, heights);
            this.terrainHelper(((col1 + col2) / 2), col2, 
                    ((row1 + row2) / 2), row2, false, heights);
        }
    }

    // to generate the Mountain Island Heights
    ArrayList<ArrayList<Double>> genMountainHeights() {
        //arraylist of arraylists of heights. The outer list is a list of
        //columns and the inner lists are all the heights within those columns
        ArrayList<ArrayList<Double>> heights = 
                new ArrayList<ArrayList<Double>>();
        for (Integer x = 0; x < ISLAND_SIZE + 1; x += 1) {
            ArrayList<Double> ys = new ArrayList<Double>();
            for (Integer y = 0; y < ISLAND_SIZE + 1; y += 1) {
                ys.add(MAX_HEIGHT - (Math.abs(x.doubleValue() - 
                        ForbiddenIslandWorld.MOUNTAIN_PEAK.x) + 
                        Math.abs(y.doubleValue() - 
                                ForbiddenIslandWorld.MOUNTAIN_PEAK.y)));
            }
            heights.add(ys);
        }
        return heights;
    }

    // to generate the Random Island Heights
    ArrayList<ArrayList<Double>> genRandomHeights() {
        ArrayList<ArrayList<Double>> heights = 
                new ArrayList<ArrayList<Double>>();
        Integer low = 1;
        Integer high = MAX_HEIGHT.intValue();
        for (Integer i = 0; i < ISLAND_SIZE + 1; i += 1) {
            ArrayList<Double> ys = new ArrayList<Double>();
            for (int p = 0; p < ISLAND_SIZE + 1; p += 1) {
                ys.add(Math.floor(Math.random() * (1 + high - low)) + low);
            }
            heights.add(ys);
        }
        return heights;
    }

    public void engineer(IList<Cell> cells, Player p1, Player p2) {
        IList<Cell> temp = cells;
        for (Cell c : temp) {
            if (c.hasPlayer(p1)) {
                c.height = c.height + 5;
                p1.top.height = p1.top.height + 5;
                p1.bottom.height = p1.bottom.height + 5;
                p1.left.height = p1.left.height + 5;
                p1.right.height = p1.right.height + 5;
                p1.top.left.height = p1.top.left.height + 5;
                p1.top.right.height = p1.top.right.height + 5;
                p1.bottom.left.height = p1.bottom.left.height + 5;
                p1.bottom.right.height = p1.bottom.right.height + 5;
                p1.top.top.height = p1.top.top.height + 5;
                p1.top.top.left.height = p1.top.top.left.height + 5;
                p1.top.top.right.height = p1.top.top.right.height + 5;
                p1.top.top.left.left.height = p1.top.top.left.left.height + 5;
                p1.top.top.right.right.height = p1.top.top.right.right.height + 5;
                p1.top.left.left.height = p1.top.left.left.height + 5;
                p1.top.right.right.height = p1.top.right.right.height + 5;
                p1.left.left.height = p1.left.left.height + 5;
                p1.right.right.height = p1.right.right.height + 5;
                p1.bottom.left.left.height = p1.bottom.left.left.height + 5;
                p1.bottom.right.right.height = p1.bottom.right.right.height + 5;
                p1.bottom.bottom.left.left.height = p1.bottom.bottom.left.left.height + 5;
                p1.bottom.bottom.right.right.height = p1.bottom.bottom.right.right.height + 5;
            }
            else if (c.hasPlayer(p2)) {
                c.height = c.height + 5;
                p2.top.height = p2.top.height + 5;
                p2.bottom.height = p2.bottom.height + 5;
                p2.left.height = p2.left.height + 5;
                p2.right.height = p2.right.height + 5;
                p2.top.left.height = p2.top.left.height + 5;
                p2.top.right.height = p2.top.right.height + 5;
                p2.bottom.left.height = p2.bottom.left.height + 5;
                p2.bottom.right.height = p2.bottom.right.height + 5;
                p2.top.top.height = p2.top.top.height + 5;
                p2.top.top.left.height = p2.top.top.left.height + 5;
                p2.top.top.right.height = p2.top.top.right.height + 5;
                p2.top.top.left.left.height = p2.top.top.left.left.height + 5;
                p2.top.top.right.right.height = p2.top.top.right.right.height + 5;
                p2.top.left.left.height = p2.top.left.left.height + 5;
                p2.top.right.right.height = p2.top.right.right.height + 5;
                p2.left.left.height = p2.left.left.height + 5;
                p2.right.right.height = p2.right.right.height + 5;
                p2.bottom.left.left.height = p2.bottom.left.left.height + 5;
                p2.bottom.right.right.height = p2.bottom.right.right.height + 5;
                p2.bottom.bottom.left.left.height = p2.bottom.bottom.left.left.height + 5;
                p2.bottom.bottom.right.right.height = p2.bottom.bottom.right.right.height + 5;
            }
        }
    }

    // to generate the Random Terrain Cells
    ArrayList<ArrayList<Cell>> genTerrainCells(
            ArrayList<ArrayList<Double>> heights) {
        ArrayList<ArrayList<Cell>> aaCell = new ArrayList<ArrayList<Cell>>();
        for (Integer col = 0; col < ISLAND_SIZE + 1; col += 1 ) {
            ArrayList<Cell> aCell = new ArrayList<Cell>();
            for (Integer row = 0; row < ISLAND_SIZE + 1; row += 1) {
                if (heights.get(col).get(row) <= 0) {
                    aCell.add(new OceanCell(0, col, row, true));
                }
                else {
                    aCell.add(new Cell(heights.get(col).get(row), col, row, false));
                }
            }
            aaCell.add(aCell);
        }
        return aaCell;
    }

    // to generate the Island Cells
    ArrayList<ArrayList<Cell>> genCells(
            ArrayList<ArrayList<Double>> heights) {
        ArrayList<ArrayList<Cell>> aaCell = new ArrayList<ArrayList<Cell>>();
        for (Integer col = 0; col < ISLAND_SIZE + 1; col += 1) {
            ArrayList<Cell> aCell = new ArrayList<Cell>();
            for (Integer row = 0; row < ISLAND_SIZE + 1; row += 1) {
                if ((Math.abs(col.doubleValue() - 
                        ForbiddenIslandWorld.MOUNTAIN_PEAK.x) + 
                        Math.abs(row.doubleValue() - 
                                ForbiddenIslandWorld.MOUNTAIN_PEAK.y)) >= 32) {
                    aCell.add(new OceanCell(0, col, row, true));
                }
                else {
                    aCell.add(new Cell(heights.get(col).get(row), col, row, false));
                }
            }
            aaCell.add(aCell);
        }
        return aaCell;
    }

    // links all cells together so that each cell references 
    //  its neighbors correctly
    ArrayList<ArrayList<Cell>> setLinks(ArrayList<ArrayList<Cell>> cells) {
        ArrayList<ArrayList<Cell>> curArr = cells;
        for (int col = 0; col < curArr.size(); col += 1) {
            for (int row = 0; row < curArr.get(col).size(); row += 1) {
                Cell cur = curArr.get(col).get(row);
                if (col == 0) {
                    cur.left = cur;
                }
                else {
                    cur.left = curArr.get(col - 1).get(row);
                }
                if (row == 0) {
                    cur.top = cur;
                }
                else {
                    cur.top = curArr.get(col).get(row - 1);
                }
                if (col == ISLAND_SIZE) {
                    cur.right = cur;
                }
                else {
                    cur.right = curArr.get(col + 1).get(row);
                }
                if (row == ISLAND_SIZE) {
                    cur.bottom = cur;
                }
                else {
                    cur.bottom = curArr.get(col).get(row + 1);
                }
                curArr.get(col).set(row, cur);
            }
        }
        return curArr;   
    }
    // to generate the board
    IList<Cell> genBoard(ArrayList<ArrayList<Cell>> aaCell) {
        ArrayList<ArrayList<Cell>> currArr = setLinks(aaCell);
        IList<Cell> cells = new MtList<Cell>();
        for (ArrayList<Cell> row : currArr) {
            for (Cell c : row) {
                cells = new ConsList<Cell>(c, cells);
            }
        }
        return cells;
    }
    //EFFECT: updates the world on a key press
    public void onKeyEvent(String ke) {
        WorldScene bg = new WorldScene(WINDOW_LENGTH, WINDOW_HEIGHT);
        IList<Cell> cells = this.board;
        ArrayList<ArrayList<Cell>> arrM = this.genCells(this.genMountainHeights());
        ArrayList<ArrayList<Cell>> arrR = this.genCells(this.genRandomHeights());
        ArrayList<ArrayList<Cell>> arrT = this.genTerrainCells(this.genRandomTerrain());
        Player player1 = this.p1;
        Player player2 = this.p2;
        ArrayList<Target> pieces = new ArrayList<Target>();
        ForbiddenIslandWorld start = this;
        HelicopterTarget helipiece = new HelicopterTarget(32, 32, false);
        IList<Cell> p1cells = this.p1.onFlood(cells);
        IList<Cell> p2cells = this.p2.onFlood(cells);
        if (ke.compareTo("r") == 0) {
            cells = this.genBoard(arrR);
            this.board = cells;
            this.waterHeight = 0;
            player1 = new Player(0, 0, new MtList<Target>(), 0, null, null, null, null);
            player2 = new Player(0, 0, new MtList<Target>(), 0, null, null, null, null);
            player1.placePerson(arrR);
            player2.placePerson(arrR);
            player1.setCells(arrR);
            player2.setCells(arrR);
            this.p1 = player1; 
            this.p2 = player2;
            pieces.add(new Target(32, 32, false));
            pieces.add(new Target(32, 33, false));
            pieces.add(new Target(32, 34, false));
            pieces.add(new Target(32, 35, false));
            pieces.add(new Target(32, 36, false));
            for (Target t: pieces) {
                t.placeTarget(arrR);
            }
            if (pieces.isEmpty()) {
                helipiece = new HelicopterTarget(ForbiddenIslandWorld.MOUNTAIN_PEAK.x, 
                        ForbiddenIslandWorld.MOUNTAIN_PEAK.y, false);
                helipiece.placeHeli(arrR);
            }

            this.heli = helipiece;
            this.targets = pieces;
            start = new ForbiddenIslandWorld(cells, 0, player1, player2, pieces, helipiece);
        }
        if (ke.compareTo("m") == 0) {
            cells = this.genBoard(arrM);
            this.board = cells;
            this.waterHeight = 0;
            player1 = new Player(0, 0, new MtList<Target>(), 0, null, null, null, null);
            player2 = new Player(0, 0, new MtList<Target>(), 0, null, null, null, null);
            player1.placePerson(arrM);
            player2.placePerson(arrM);
            player1.setCells(arrM);
            player2.setCells(arrM);
            this.p1 = player1; 
            this.p2 = player2;
            pieces.add(new Target(32, 32, false));
            pieces.add(new Target(32, 33, false));
            pieces.add(new Target(32, 34, false));
            pieces.add(new Target(32, 35, false));
            pieces.add(new Target(32, 36, false));
            for (Target t: pieces) {
                t.placeTarget(arrM);
            }
            if (pieces.isEmpty()) {
                helipiece = new HelicopterTarget(ForbiddenIslandWorld.MOUNTAIN_PEAK.x, 
                        ForbiddenIslandWorld.MOUNTAIN_PEAK.y, false);
                helipiece.placeHeli(arrM);
            }

            this.heli = helipiece;
            this.targets = pieces;
            start = new ForbiddenIslandWorld(cells, 0, player1, player2, pieces, helipiece);
        }
        if (ke.compareTo("t") == 0) {
            cells = this.genBoard(arrT);
            this.board = cells;
            this.waterHeight = 0;
            player1 = new Player(0, 0, new MtList<Target>(), 0, null, null, null, null);
            player2 = new Player(0, 0, new MtList<Target>(), 0, null, null, null, null);
            player1.placePerson(arrT);
            player2.placePerson(arrT);
            player1.setCells(arrT);
            player2.setCells(arrT);
            this.p1 = player1; 
            this.p2 = player2;
            pieces.add(new Target(32, 32, false));
            pieces.add(new Target(32, 33, false));
            pieces.add(new Target(32, 34, false));
            pieces.add(new Target(32, 35, false));
            pieces.add(new Target(32, 36, false));
            for (Target t: pieces) {
                t.placeTarget(arrT);
            }
            if (pieces.isEmpty()) {
                helipiece = new HelicopterTarget(ForbiddenIslandWorld.MOUNTAIN_PEAK.x, 
                        ForbiddenIslandWorld.MOUNTAIN_PEAK.y, false);
                helipiece.placeHeli(arrT);
            }

            this.heli = helipiece;
            this.targets = pieces;
            start = new ForbiddenIslandWorld(cells, 0, player1, player2, pieces, helipiece);
        }
        if (p1cells.isCons() || p2cells.isCons()) {
            return;
        }
        else if (heli.fly(p1, p2)) {
            return;
        }
        if ((ke.compareTo("up") == 0) || (ke.compareTo("down") == 0) || 
                (ke.compareTo("left") == 0) || (ke.compareTo("right") == 0)) {
            player1.moveOnKey(ke);
            this.p1 = player1;
            if (this.targets.isEmpty()) {
                helipiece = new HelicopterTarget(ForbiddenIslandWorld.MOUNTAIN_PEAK.x, 
                        ForbiddenIslandWorld.MOUNTAIN_PEAK.y, false);
                helipiece.placeHeli(arrM);
            }
            this.heli = helipiece;
            start = new ForbiddenIslandWorld(cells, 0, player1, player2, pieces, helipiece);
        }
        if ((ke.compareTo("w") == 0) || (ke.compareTo("a") == 0) || 
                (ke.compareTo("s") == 0) || (ke.compareTo("d") == 0)) {
            player2.moveOnKey(ke);
            this.p2 = player2;
            if (this.targets.isEmpty()) {
                helipiece = new HelicopterTarget(ForbiddenIslandWorld.MOUNTAIN_PEAK.x, 
                        ForbiddenIslandWorld.MOUNTAIN_PEAK.y, false);
                helipiece.placeHeli(arrM);
            }
            this.heli = helipiece;
            start = new ForbiddenIslandWorld(cells, 0, player1, player2, pieces, helipiece);
        }
    }


    // to update the cells on the board on tick
    public void updateCells() {
        IList<Cell> curBoard = this.board;
        for (Cell c : curBoard) {
            if (c.height < this.waterHeight && c.hasFlood()) {
                c.isFlooded = true;
            }
        }
    }
    // to update the targets on the board on tick
    public void updateTargets() {
        ArrayList<Target> cur = this.targets;
        ArrayList<Target> result = new ArrayList<Target>();
        for (Target t: cur) {
            result.add(t);
        }
        Player player1 = this.p1;
        Player player2 = this.p2;
        for (int i = 0; i < result.size(); i += 1) {
            if (result.get(i).hasPlayer(player1) || result.get(i).hasPlayer(player2)) {
                result.remove(i);
            }
        }
        this.targets = result;
    }



    // to override onMouseExited
    public void onMouseExited() {
        // overridden because we don't use it 
    }

    // to override onMouseExited
    public void onMouseEntered() { 
        // overridden because we don't use it 
    }

    // to override onMouseClicked
    public void onMouseClicked() { 
        // overridden because we don't use it
    }

    //EFFECT: updates the world on tick
    public void onTick() {
        this.tick = this.tick + 1;
        IList<Cell> cells = this.board;
        IList<Cell> p1cells = this.p1.onFlood(cells);
        IList<Cell> p2cells = this.p2.onFlood(cells);
        if (p1cells.isCons() || p2cells.isCons()) {
            return;
        }
        else if (heli.fly(p1, p2)) {
            return;
        }
        else {
            this.tick = this.tick + 1;
            if (this.tick % 10 == 0) {
                this.waterHeight = this.waterHeight + 1;
            }
        }
        this.updateCells();
    }

    // makes a WorldScene (initializes)
    public WorldScene makeScene() {
        ArrayList<Target> curTargets = this.targets;
        // a blank background
        WorldScene bg = new WorldScene(WINDOW_LENGTH, WINDOW_HEIGHT);
        for (Cell c : this.board) {
            c.renderCell(bg, this.waterHeight);
        }
        this.p1.renderPlayer(bg, true);
        this.p2.renderPlayer(bg, false);
        IList<Cell> cells = this.board;
        IList<Cell> p1cells = this.p1.onFlood(cells);
        IList<Cell> p2cells = this.p2.onFlood(cells);
        if (p1cells.isCons() || p2cells.isCons()) {
            return this.makeDrownScene(bg);
        }
        else if (heli.fly(p1, p2)) {
            return this.makeFlyScene(bg);
        }
        for (Target t: curTargets) {
            this.updateTargets();
            t.renderTarget(bg);
        }
        if (curTargets.isEmpty()) {
            this.heli.renderHeli(bg);
        }
        this.renderScore(bg, this.p1, true);
        this.renderScore(bg, this.p2, false);
        this.renderTime(bg);
        return bg;
    }
    // draws the score of each player onto the WorldScene
    public WorldScene renderScore(WorldScene base, Player p, boolean isLeft) {
        if (isLeft) {
            base.placeImageXY(p.drawScore(), 130, 30);
            base.placeImageXY(new TextImage("Player 1 Steps:", 15, 
                    FontStyle.BOLD,  Color.pink), 60, 30);
            return base;
        }
        else {
            base.placeImageXY(p.drawScore(), 130, 43);
            base.placeImageXY(new TextImage("Player 2 Steps:", 15, 
                    FontStyle.BOLD,  Color.pink), 60, 43);
            return base;
        }
    }
    // draws the time until the world is flooded given the current worldscene
    public WorldScene renderTime(WorldScene base) {
        base.placeImageXY(this.drawTime(), 600, 30);
        base.placeImageXY(new TextImage("Time to Sink:", 15, 
                FontStyle.BOLD,  Color.pink), 538, 30) ;
        return base;
    }
    // draws the time onto the board
    public WorldImage drawTime() {
        int max = MAX_HEIGHT.intValue();
        int val = max - this.waterHeight;
        return new TextImage(Integer.toString(val), 15, FontStyle.BOLD,  Color.pink);
    }
    // after either player has drowned, this is shown, signifying the
    //  players have lost the game
    public WorldScene makeDrownScene(WorldScene bg) {
        bg.placeImageXY(new TextImage("You Drowned!", 50, Color.red), 
                WINDOW_LENGTH / 2,  WINDOW_HEIGHT / 2);
        bg.placeImageXY(
                new TextImage("Player 1 Score: " + Integer.toString(this.p1.steps) + " steps",
                        25,  Color.red), 
                WINDOW_LENGTH / 2 + 50, WINDOW_HEIGHT / 2 + 50);
        bg.placeImageXY(
                new TextImage("Player 2 Score: " + Integer.toString(this.p2.steps) + " steps",
                        25,  Color.red), 
                WINDOW_LENGTH / 2 + 50, WINDOW_HEIGHT / 2 + 100);
        return bg;
    }
    // after both players reach the rebuilt helicopter, this is shown,
    //  signifying the players have won the game
    public WorldScene makeFlyScene(WorldScene bg) {
        bg.placeImageXY(new TextImage("You Flew Away!", 50, Color.green), 
                WINDOW_LENGTH / 2,  WINDOW_HEIGHT / 2);
        bg.placeImageXY(
                new TextImage("Player 1 Score: " + Integer.toString(this.p1.steps) + " steps",
                        25,  Color.green), 
                WINDOW_LENGTH / 2 + 50, WINDOW_HEIGHT / 2 + 50);
        bg.placeImageXY(
                new TextImage("Player 2 Score: " + Integer.toString(this.p2.steps) + " steps",
                        25,  Color.green), 
                WINDOW_LENGTH / 2 + 50, WINDOW_HEIGHT / 2 + 100);
        return bg;
    }


}

//a class for Examples
class ExamplesForbiddenIslandWorld {

    Cell c1;
    Cell c2;
    Cell c3;
    OceanCell o1;
    OceanCell o2;
    Cell f1;
    Cell f2;
    Cell f3;
    Cell f4;
    Player p1;
    Player p2;
    Target t1;
    Target t2;
    HelicopterTarget h1;
    HelicopterTarget h2;
    IList<Cell> mtcell;
    IList<Cell> randcell;
    ForbiddenIslandWorld w1;
    IList<Cell> l1;
    IList<Cell> l2;
    IList<Cell> mt;
    ArrayList<ArrayList<Cell>> arrMtCell;
    ArrayList<ArrayList<Cell>> arrTCell;
    ArrayList<ArrayList<Cell>> arrRanCell;
    ArrayList<ArrayList<Double>> arrMtHeights;
    ArrayList<ArrayList<Double>> arrRandHeights;
    ArrayList<ArrayList<Double>> arrTHeights;

    // our initial data
    void initData() {
        this.w1 = new ForbiddenIslandWorld(0);
        this.c1 = new Cell(1.22, 10, 5, this.c1, this.c2, this.c3, this.c1, false);
        this.c2 = new Cell(8, 40, 30, this.c1, this.c2, this.c3, this.c1, false);
        this.c3 = new Cell(9.0, 32, 32, this.c1, this.c2, this.c3, this.c1, true);
        this.o1 = new OceanCell(0, 1, 1, false);
        this.o2 = new OceanCell(0, 64, 64, false);
        this.f1 = new Cell(0, 4, 19, this.f2, this.f3, this.f4, this.f1, true);
        this.f2 = new Cell(-4.2, 6, 40, this.f2, this.f3, this.f4, this.f1, true);
        this.f3 = new Cell(-10, 5, 23, this.f2, this.f3, this.f4, this.f1, true);
        this.f4 = new Cell(-16, 62, 34, this.f2, this.f3, this.f4, this.f1, true);
        this.p1 = new Player(32, 32, new MtList<Target>(), 0, null, null, null, null);
        this.p2 = new Player(60, 60, new MtList<Target>(), 0, null, null, null, null);
        this.t1 = new Target(32, 32, false);
        this.t2 = new Target(40, 40, false);
        this.h1 = new HelicopterTarget(16, 16, false);
        this.h2 = new HelicopterTarget(32, 32, true);
        this.l1 = new ConsList<Cell>(this.c1, 
                new ConsList<Cell>(this.c2, this.mt));
        this.l2 = new ConsList<Cell>(this.c3, this.mt);
        this.mt = new MtList<Cell>();
        this.arrMtCell = this.w1.genCells(this.w1.genMountainHeights());
        this.arrTCell = this.w1.genTerrainCells(this.w1.genRandomTerrain());
        this.arrRanCell = this.w1.genCells(this.w1.genRandomHeights());
        this.arrMtHeights = this.w1.genMountainHeights();
        this.arrRandHeights = this.w1.genRandomHeights();
        this.arrTHeights = this.w1.genRandomTerrain();

    }

    // a test for the isCons method
    void testIsCons(Tester t) {
        this.initData();
        t.checkExpect(this.l1.isCons(), true);
        t.checkExpect(this.l2.isCons(), true);
        t.checkExpect(this.mt.isCons(), false);
    }

    // a test for the asCons method
    void testAsCons(Tester t) {
        this.initData();
        t.checkExpect(this.l1.asCons(), this.l1);
        t.checkException(new RuntimeException("Can't get the cons of an empty list!"),
                this.mt, "asCons");
    }

    void testRemove(Tester t) {
        this.initData();
        t.checkExpect(this.l1.remove(this.c2), new ConsList<Cell>(this.c1, this.mt));
        t.checkExpect(this.mt.remove(this.c1), this.mt);
    }

    void testSetTop(Tester t) {
        this.initData();
        this.c1.setTop(this.c2);
        t.checkExpect(this.c1.top, this.c2);
        this.c3.setTop(this.f1);
        t.checkExpect(this.c3.top, this.f1);
    }
    void testSetBottom(Tester t) {
        this.initData();
        this.c1.setBottom(this.c3);
        t.checkExpect(this.c1.bottom, this.c3);
        this.c3.setBottom(this.f3);
        t.checkExpect(this.c3.bottom, this.f3);

    }

    void testSetLeft(Tester t) {
        this.initData();
        this.c2.setLeft(this.c1);
        t.checkExpect(this.c2.left, this.c1);
        this.f1.setLeft(this.c3);
        t.checkExpect(this.f1.left, this.c3);
    }

    void testSetRight(Tester t) {
        this.initData();
        this.f4.setRight(this.c1);
        t.checkExpect(this.f4.right, this.c1);
        this.f2.setRight(this.c3);
        t.checkExpect(this.f2.right, this.c3);
    }

    void testMoveRight(Tester t) {
        this.initData();
        this.p1.moveRight();
        t.checkExpect(this.p1.x, 33);
        this.p2.moveRight();
        t.checkExpect(this.p2.x, 61);
    }
    void testMoveLeft(Tester t) {
        this.initData();
        this.p1.moveLeft();
        t.checkExpect(this.p1.x, 31);
        this.p2.moveLeft();
        t.checkExpect(this.p2.x, 59);
    }
    void testMoveUp(Tester t) {
        this.initData();
        this.p1.moveUp();
        t.checkExpect(this.p1.y, 31);
        this.p2.moveUp();
        t.checkExpect(this.p2.y, 59);
    }
    void testMoveDown(Tester t) {
        this.initData();
        this.p1.moveDown();
        t.checkExpect(this.p1.y, 33);
        this.p2.moveDown();
        t.checkExpect(this.p2.y, 61);
    }

    void testAddPart(Tester t) {
        this.initData();
        this.p1.addPart(this.t1);
        t.checkExpect(this.p1.parts, new ConsList<Target>(this.t1, new MtList<Target>()));
        this.p2.addPart(this.t2);
        t.checkExpect(this.p2.parts,  new ConsList<Target>(this.t2, new MtList<Target>()));
    }

    void testChangePicked(Tester t) {
        this.initData();
        this.h2.changePicked(this.p1);
        t.checkExpect(this.h2.isPicked, false);
        this.h1.changePicked(this.p2);
        t.checkExpect(this.h1.isPicked, false);
    }

    // a test for the HasNextList method
    void testHasNextList(Tester t) {
        this.initData();
        t.checkExpect(this.l1.hasNextList(), true);
        t.checkExpect(this.mt.hasNextList(), false);
    }

    // a test for the isOcean method
    void testIsOcean(Tester t) {
        this.initData();
        t.checkExpect(this.c1.isOcean(), false);
        t.checkExpect(this.o1.isOcean(), true);
    }

    /*
  void testHasFlood(Tester t) {
      this.initData();
      t.checkExpect(this.c1.hasFlood(), false);
      t.checkExpect(this.f1.hasFlood(), true);
  }
     */

    void testSameCell(Tester t) {
        this.initData();
        t.checkExpect(this.c1.sameCell(this.c1), true);
        t.checkExpect(this.c1.sameCell(this.f1), false);
        t.checkExpect(this.o2.sameCell(new OceanCell(0.0, 0, 0, false)), false);
    }

    void testIsCell(Tester t) {
        this.initData();
        t.checkExpect(this.c1.isCell(), true);
        t.checkExpect(this.o1.isCell(), false);
        t.checkExpect(this.f1.isCell(), true);
    }

    void testIsTarget(Tester t) {
        this.initData();
        t.checkExpect(this.t1.isTarget(), true);
        t.checkExpect(this.t2.isTarget(), true);
        t.checkExpect(this.h1.isTarget(), true);
    }

    void testHasPlayer(Tester t) {
        this.initData();
        t.checkExpect(this.c3.hasPlayer(this.p1), true);
        t.checkExpect(this.f1.hasPlayer(this.p2), false);
        t.checkExpect(this.o1.hasPlayer(this.p1), false);
        t.checkExpect(this.t1.hasPlayer(this.p1), true);
        t.checkExpect(this.t2.hasPlayer(this.p2), false);
    }


    void testFly(Tester t) {
        this.initData();
        t.checkExpect(this.h1.fly(this.p1, this.p2), false);
        t.checkExpect(this.h2.fly(this.p1, this.p1), false);
    }

    /*
  void testDrawCell(Tester t) {
      this.initData();
      t.checkExpect(this.c1.drawCell(0), new RectangleImage(ForbiddenIslandWorld.CELL_SIZE, 
                ForbiddenIslandWorld.CELL_SIZE, 
                OutlineMode.SOLID, this.getColor(water)))
  }
     */

    // a test for the getColor method
    void testGetColor(Tester t) {
        this.initData();
        t.checkExpect(this.c1.getColor(0), new Color(95, 175, 12));
        t.checkExpect(this.c2.getColor(0), new Color(135, 195, 66));
        //t.checkExpect(this.c3.getColor(0), new Color(135, 195, 67));
        t.checkExpect(this.o1.getColor(0), new Color(0, 100, 204));
        t.checkExpect(this.o2.getColor(0), new Color(0, 100, 204));
        //t.checkExpect(this.f1.getColor(0), new Color(0, 100, 204));
        //t.checkExpect(this.f2.getColor(0), new Color(0, 74, 151));
        //t.checkExpect(this.f3.getColor(0), new Color(0, 38, 77));
        //t.checkExpect(this.f4.getColor(0), new Color(0, 0, 0));
    }

    // a test for the getLandColor method
    void testGetLandColor(Tester t) {
        this.initData();
        t.checkExpect(this.c1.getLandColor(this.c1.height), 
                new Color(95, 175, 12));
        t.checkExpect(this.c2.getLandColor(this.c2.height), 
                new Color(135, 195, 66));
        //t.checkExpect(this.c3.getLandColor(this.c3.height), 
        //        new Color(135, 195, 67));
    }

    // a test for the getFloodColor method
    //void testGetFloodColor(Tester t) {
    //    this.initData();
    //    t.checkExpect(this.f1.getFloodColor(this.f1.height), 
    //            new Color(0, 100, 204));
    //    t.checkExpect(this.f2.getFloodColor(this.f2.height), 
    //            new Color(0, 74, 151));
    //    t.checkExpect(this.f3.getFloodColor(this.f3.height), 
    //            new Color(0, 38, 77));
    //    t.checkExpect(this.f4.getFloodColor(this.f4.height), 
    //            new Color(0, 0, 0));
    //}

    // a test for the getOceanColor method
    void testGetOceanColor(Tester t) {
        this.initData();
        t.checkExpect(this.o1.getOceanColor(), new Color(0, 100, 204));
        t.checkExpect(this.o2.getOceanColor(), new Color(0, 100, 204));
    }
    // a test for running our game
    void testGame(Tester t) {
        new ForbiddenIslandWorld("r").bigBang(
                ForbiddenIslandWorld.WINDOW_HEIGHT, 
                ForbiddenIslandWorld.WINDOW_LENGTH, 0.1);
    }

    // to test mountain island heights
    void testGenMountainHeights(Tester t) {
        this.initData();
        ArrayList<ArrayList<Double>> mh = this.w1.genMountainHeights();
        t.checkExpect(mh.get(32).get(16), 16.0);
        t.checkExpect(mh.get(63).get(63), -30.0);
        t.checkExpect(mh.get(32).get(32), 32.0);
    }
    
    // to test random island heights
    void testGenRandomHeights(Tester t) {
        this.initData();
        for (ArrayList<Double> arr: this.arrRandHeights) {
            for (Double d : arr) {
                t.checkExpect(d <= ForbiddenIslandWorld.MAX_HEIGHT , true);
                t.checkExpect(d >= 0, true);
            }
        }
    }
    
    void testGenTerrainHeights(Tester t) {
        this.initData();
        for (ArrayList<Double> arr: this.arrTHeights) {
            for (Double d : arr) {
                t.checkExpect(d <= ForbiddenIslandWorld.MAX_HEIGHT , true);
                
            }
        }
    }
    
    

    // to test mountain cells
    void testGenCells(Tester t) {
        this.initData();
        t.checkExpect(this.w1.genCells(this.w1.genMountainHeights()).get(32).get(16), 
                new Cell(16.0, 32, 16, false));
    }
    
    
    // to test the set links function
    void testSetLinks(Tester t) {
        this.initData();
        this.arrMtCell.get(0).get(0).setRight(new Cell(32, 5, 40, true));
        t.checkExpect(this.arrMtCell.get(0).get(0).right, new Cell(32, 5, 40, true));
        this.w1.setLinks(this.arrMtCell);
        for (int col = 0; col < ForbiddenIslandWorld.ISLAND_SIZE; col = col + 1) {
            for (int row = 0; row < ForbiddenIslandWorld.ISLAND_SIZE; row = row + 1) {
                if (col ==  0) {
                    t.checkExpect(this.arrMtCell.get(col).get(row).left.x, 
                            this.arrMtCell.get(col).get(row).x);
                }
                if (col == ForbiddenIslandWorld.ISLAND_SIZE) {
                    t.checkExpect(this.arrMtCell.get(col).get(row).right.x, 
                            this.arrMtCell.get(col).get(row).x);
                }
                if (row == 0) {
                    t.checkExpect(this.arrMtCell.get(col).get(row).top.y, 
                            this.arrMtCell.get(col).get(row).y);
                }
                if (row == ForbiddenIslandWorld.ISLAND_SIZE) {
                    t.checkExpect(this.arrMtCell.get(col).get(row).bottom.y, 
                            this.arrMtCell.get(col).get(row).y);
                }
            }
        }

    }
}
